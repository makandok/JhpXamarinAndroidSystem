﻿using JhpDataSystem.model;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SyncManager
{
    public class MyFieldItem : FieldItem
    {
        //public string listName { get; set; }
        //public string lookupValue { get; set; }
    }
}
